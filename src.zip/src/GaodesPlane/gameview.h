#ifndef GAMEVIEW_H
#define GAMEVIEW_H

#include <QGraphicsView>
#include <QIcon>
#include "qplane.h"
#include "qenemy.h"
#include "qbolling.h"
#include "qbullet.h"
#include "sqldata.h"
#include "qbolling.h"
#include <QTimer>
#include <QLabel>
#include <QPushButton>
#include <QProgressBar>

class GameView : public QGraphicsView
{
    Q_OBJECT
public:
    GameView(QWidget *parent);  
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);
    void mouseMoveEvent(QMouseEvent *event);

public slots:
    void productplane();
    void productbullet();
    void timers();
    void timerfive();
private:
    QWidget *parent;
    QGraphicsScene *scene;
    QBullet *bullet;
    QEnemy *enemy1;
    QEnemy *enemy2;
    QEnemy *enemy3;
    QPlane *plane;
    QTimer *timer;
    QTimer *timer2;
    QTimer *timer3;
    QTimer *timer4;
    QTimer *timer5;
    Sqldata *mydata;
    QBolling *bl;
    QBolling *b2;
    QBolling *b3;
    QBolling *al;
    QBolling *a2;
    QBolling *a3;
    QBolling *a4;
    int timernum;
    int retimernum;
    int level;//�л��Ĳ���
    bool key_space;
    bool key_esc;
    QLabel *label2;
    QPushButton *bbutton;
    QProgressBar *pProgressBar;  //������
};

#endif // GAMEVIEW_H
