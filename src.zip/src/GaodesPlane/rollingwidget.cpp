#include "rollingwidget.h"
#include "gameview.h"
#include "menuwidget.h"
#include <Qtsql/QSqlDatabase>
#include <Qtsql/QSqlQuery>
#include <QPropertyAnimation>
#include <QLabel>

#include <QMessageBox>
#include <qDebug>

int RollingWidget::retime = 0;
//int RollingWidget::destroy = 0;

RollingWidget::RollingWidget(QWidget *parent) :
    QWidget(parent)
{
//    //���ش��ڱ߿�
    setWindowFlags(Qt::FramelessWindowHint);
    this->setFixedSize(600,650);
    QBullet::getgore = 0;
 //   destroy = 0; //���λ��0
    retime = 0;  //��־λ��0
    this->setFixedSize(600,650);
    this->setWindowIcon(QIcon("image/icon.png"));
    this->setWindowTitle("����ս��");

   //this->setStyleSheet("background:transparent;border:0px");
    this->setStyleSheet("QWideget{background-color:transparent;border:0px};");  //����͸�� ��ֹnew�����Ķ��󱻸��ǵ�
    QLabel *label3 = new QLabel(this);
    label3->setStyleSheet("QLabel{border-image:url("+GameRankWidget::SceneName+");}");
    QLabel *label4 = new QLabel(this);
    label4->setStyleSheet("QLabel{border-image:url("+GameRankWidget::SceneName+");}");
    QLabel *label5 = new QLabel(this);
    label5->setStyleSheet("QLabel{border-image:url("+GameRankWidget::SceneName+");}");

    QPropertyAnimation *animationl1 = new QPropertyAnimation(label3,"geometry",this);
    animationl1->setDuration(7000);
    animationl1->setKeyValueAt(0,QRect(0,-650,600,650));
    animationl1->setKeyValueAt(1,QRect(0,650,600,650));

    QPropertyAnimation *animationl2 = new QPropertyAnimation(label4,"geometry",this);
    animationl2->setDuration(7000);
    animationl2->setKeyValueAt(0,QRect(0,-1300,600,650));
    animationl2->setKeyValueAt(1,QRect(0,0,600,650));

    QPropertyAnimation *animationl3 = new QPropertyAnimation(label5,"geometry",this);
    animationl3->setDuration(3500);
    animationl3->setKeyValueAt(0,QRect(0,0,600,650));
    animationl3->setKeyValueAt(1,QRect(0,650,600,650));

    this->group1 = new QParallelAnimationGroup;
    group1->addAnimation(animationl1);
    group1->addAnimation(animationl2);
    group1->addAnimation(animationl3);
    group1->start();
 //   group1->stop();
    group1->setLoopCount(-1); //ѭ��



    //////////////////�����������ݿ���ȡģ��////////////////
    mydata = Sqldata::getIstance();
    QSqlDatabase db = Sqldata::getdb();
    QSqlQuery query(db);
    QString S =QString("select * from people where name='%1'and psw='%2'").arg(Widget::usernames).arg(Widget::passwords);
    query.exec(S);
    QString newagain = QString("1");
    if(query.next())
    {
        qDebug()<<query.value(4).toInt();
        if(query.value(4).toInt()==1)
        {
            retime = 1;    //��־λ��1
        }
        QString S2 = QString("update people set isagain='%1'  where name='%2'and psw='%3'").arg(newagain).arg(Widget::usernames).arg(Widget::passwords);
        query.exec(S2);      
        qDebug()<<S2;
        qDebug()<<query.value(4).toInt();
    }
    /////////////////////////////////////
//    if(destroy == 1)
//    {
//        delete this;
//    }
    GameView *gv = new GameView(this);
    gv->show();
}


RollingWidget::~RollingWidget()
{
    qDebug()<<"xugou";
    delete group1;
}
