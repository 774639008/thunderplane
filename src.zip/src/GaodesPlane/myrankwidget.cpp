#include "myrankwidget.h"
#include "cuipoint.h"
#include <QVariant>
#include <qDebug>
#include <QHeaderView>

MyrankWidget::MyrankWidget(QWidget *parent) :
    QWidget(parent)
{
    QFont ft;
    ft.setPointSize(12);
    ft.setBold(true);

    //���ش��ڱ߿�
    setWindowFlags(Qt::FramelessWindowHint);
    this->setFixedSize(600,400);
    //���ñ���ͼƬ
    this->label = new QLabel(this);
    this->label->setGeometry(0,0,600,400);
    this->label->setPixmap(QPixmap("image/myrank.png"));

    this->label = new QLabel(this);
    this->label->setGeometry(180,50,50,36);
    this->label->setPixmap(QPixmap("image/rank.png"));

    this->label = new QLabel(this);
    this->label->setGeometry(275,50,50,36);
    this->label->setPixmap(QPixmap("image/name.png"));

    this->label = new QLabel(this);
    this->label->setGeometry(380,50,50,36);
    this->label->setPixmap(QPixmap("image/score.png"));

    this->prebutton = new QPushButton(this);
    this->prebutton->setIcon(QIcon("image/left.png"));
    this->prebutton->setFlat(true);
    this->prebutton->setIconSize(QSize(50,50));
    this->prebutton->setGeometry(50,100,100,100);
    this->prebutton->setStyleSheet("QPushButton:hover{border-image:url(image/gamerank/left.png);}");
    connect(this->prebutton,SIGNAL(clicked()),this,SLOT(prebuttons()));

    this->nextbutton = new QPushButton(this);
    this->nextbutton->setIcon(QIcon("image/right.png"));
    this->nextbutton->setFlat(true);
    this->nextbutton->setIconSize(QSize(50,50));
    this->nextbutton->setGeometry(460,100,100,100);
    this->nextbutton->setStyleSheet("QPushButton:hover{border-image:url(image/gamerank/right.png);}");
    connect(this->nextbutton,SIGNAL(clicked()),this,SLOT(nextbuttons()));


    this->rbutton = new QPushButton(this);
    this->rbutton->setIcon(QIcon("image/btn/back_peek0.png"));
    this->rbutton->setFlat(true);
    this->rbutton->setIconSize(QSize(143,45));
    this->rbutton->setGeometry(0,300,143,45);
    this->rbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/back_peek0.png);}");
    connect(this->rbutton,SIGNAL(clicked()),this,SLOT(goback()));
    this->rbutton->setShortcut(Qt::Key_Escape);


    mydata = Sqldata::getIstance();
    QSqlDatabase db = Sqldata::getdb();
    QSqlQuery query(db);
    char buf[2024]="";
    strcpy(buf,"select * from data order by score DESC limit 10 offset 0");
    query.exec(buf);
    this->mode = new QStandardItemModel(this);
    //mode->setQuery("select * from data order by score DESC limit 10 offset 0");
    mode->setRowCount(10);


    this->view = new QTableView(this);
    view->setEditTriggers(QAbstractItemView::NoEditTriggers);
    view->setGeometry(150,80,330,350);
    view->horizontalHeader()->hide();
    view->verticalHeader()->hide();
    view->setSelectionBehavior(QAbstractItemView::SelectRows);
    view->setStyleSheet("QWidget{background-color:transparent}");
    view->setShowGrid(false);
    view->setFont(ft);
    view->setModel(mode);

    this->line = 0;
    this->page = 0;

    while(query.next())
    {
        mode->setItem(line,0,new QStandardItem(QString("��%1��").arg(page*10+line+1)));
        mode->setItem(line,1,new QStandardItem(QString("%1").arg(query.value(0).toString())));
        mode->setItem(line,2,new QStandardItem(QString("%1").arg(query.value(1).toInt())));

        mode->item(line,0)->setTextAlignment(Qt::AlignCenter);
        mode->item(line,1)->setTextAlignment(Qt::AlignCenter);
        mode->item(line,2)->setTextAlignment(Qt::AlignCenter);

        mode->item(line,0)->setForeground(QBrush(QColor(255,255,255)));
        mode->item(line,1)->setForeground(QBrush(QColor(255,255,255)));
        mode->item(line,2)->setForeground(QBrush(QColor(255,255,255)));
        line++;
    }

    //ҳ��
    this->lab_page = new QLabel(this);
    QString buf1 = QString("SELECT COUNT(name) FROM data");
    query.exec(buf1);
    query.next();
    QString s = QString("%1").arg(query.value(0).toInt());
    qDebug()<<s;
    if(query.value(0).toInt()%10==0)
    {
        this->page_max = query.value(0).toInt()/10;
    }
    else
    {
        this->page_max = query.value(0).toInt()/10+1;
    }

    this->lab_page->setText(QString("ҳ�룺%1/%2").arg(page+1).arg(page_max));
    this->lab_page->setFont(ft);
    this->lab_page->setStyleSheet("Label{color:red}");
    this->lab_page->setGeometry(500,300,150,40);
    this->lab_page->setStyleSheet("color:blue;");
}

void MyrankWidget::nextbuttons()
{
    mydata = Sqldata::getIstance();
    QSqlDatabase db = Sqldata::getdb();
    QSqlQuery query(db);
    if(this->page >= page_max-1)
    {
        QMessageBox::warning(NULL,"Warning","�Ѿ������һҳ");
    }
    else
    {
        this->page++;
        mode->clear();
        QString buf = QString("select * from data order by score desc limit 10 offset %1").arg(page*10);
        query.exec(buf);

        this->line=0;
        while(query.next())
        {
            mode->setItem(line,0,new QStandardItem(QString("��%1��").arg(page*10+line+1)));
            mode->setItem(line,1,new QStandardItem(QString("%1").arg(query.value(0).toString())));
            mode->setItem(line,2,new QStandardItem(QString("%1").arg(query.value(1).toInt())));

            mode->item(line,0)->setTextAlignment(Qt::AlignCenter);
            mode->item(line,1)->setTextAlignment(Qt::AlignCenter);
            mode->item(line,2)->setTextAlignment(Qt::AlignCenter);

            mode->item(line,0)->setForeground(QBrush(QColor(255,255,255)));
            mode->item(line,1)->setForeground(QBrush(QColor(255,255,255)));
            mode->item(line,2)->setForeground(QBrush(QColor(255,255,255)));
            line++;
        }
        this->lab_page->setText(QString("ҳ�룺%1/%2").arg(page+1).arg(page_max));
    }

}

void MyrankWidget::prebuttons()
{
    mydata = Sqldata::getIstance();
    QSqlDatabase db = Sqldata::getdb();
    QSqlQuery query(db);
    if(this->page<=0)
    {
        QMessageBox::warning(NULL,"Warning","�Ѿ��ǵ�һҳ");
    }
    else
    {
        this->page--;
        mode->clear();
        QString buf = QString("select * from data order by score desc limit 10 offset %1").arg(page*10);
        query.exec(buf);

        this->line=0;
        while(query.next())
        {
            mode->setItem(line,0,new QStandardItem(QString("��%1��").arg(page*10+line+1)));
            mode->setItem(line,1,new QStandardItem(QString("%1").arg(query.value(0).toString())));
            mode->setItem(line,2,new QStandardItem(QString("%1").arg(query.value(1).toInt())));

            mode->item(line,0)->setTextAlignment(Qt::AlignCenter);
            mode->item(line,1)->setTextAlignment(Qt::AlignCenter);
            mode->item(line,2)->setTextAlignment(Qt::AlignCenter);

            mode->item(line,0)->setForeground(QBrush(QColor(255,255,255)));
            mode->item(line,1)->setForeground(QBrush(QColor(255,255,255)));
            mode->item(line,2)->setForeground(QBrush(QColor(255,255,255)));
            line++;
        }
        this->lab_page->setText(QString("ҳ�룺%1/%2").arg(page+1).arg(page_max));
    }
}

void MyrankWidget::goback()
{
    this->hide();
    CUIPoint::mw->show();
}
