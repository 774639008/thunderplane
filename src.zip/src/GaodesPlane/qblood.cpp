#include "qblood.h"

Blood::Blood(const QString & filename,QGraphicsScene *scene):PixmapItem(filename,scene)
{
    this->item_type = type_blood;
}
