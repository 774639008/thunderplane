#ifndef MYRANKWIDGET_H
#define MYRANKWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <Qtsql/QSqlDatabase>
#include <Qtsql/QSqlQuery>
#include <QTableView>
#include <QStandardItemModel>
#include "sqldata.h"

class MyrankWidget : public QWidget
{
    Q_OBJECT
public:
    explicit MyrankWidget(QWidget *parent = 0);

signals:

public slots:
    void nextbuttons();
    void prebuttons();
    void goback();


private:
    QLabel *label;
    QLabel *label1;
    QLabel *label2;
    QLabel *label3;
    QPushButton *nextbutton;
    QPushButton *prebutton;
    QPushButton *rbutton;
    Sqldata *mydata;
    QTableView *view;
    QStandardItemModel *mode;
    int line;
    int page;
    QLabel *lab_page;
    int page_max;
    int j;
    int count;
};

#endif // MYRANKWIDGET_H
