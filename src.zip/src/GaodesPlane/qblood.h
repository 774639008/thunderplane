#ifndef QBLOOD_H
#define QBLOOD_H

#include "pixmapitem.h"

class Blood: public PixmapItem
{
public:
    Blood(const QString & filename,QGraphicsScene *scene);
};

#endif // QBLOOD_H
