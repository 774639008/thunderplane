#include "qplane.h"
#include <qDebug>
#include <windows.h>
#include <QMessageBox>
#include <QPoint>
#include <QPropertyAnimation>
#include "cuipoint.h"
#include "selectwidget.h"
#include "widget.h"

int QPlane::gameover = 0;
int QPlane::bloodid = 3;

QPlane::QPlane(const QString &filename,QGraphicsScene *scene,QWidget *parent):PixmapItem(filename,scene)
{
    QFont ft;
    ft.setPointSize(25);
    this->parent = parent;
    bloodid = 3;
    gameover = 0;
    this->flag = 50;
    this->rect = PixmapItem::boundingRect();
    this->blood = 30;
    this->scene = scene;
    this->item_type = type_myplane;
    this->label = new QLabel(this->parent);
    this->label->setFont(ft);
    QString score = QString("%1").arg(QBullet::getgore);
    this->label->setText("����:"+score);
    this->label->setStyleSheet("color:red");
    this->label->setGeometry(450,0,200,100);
    this->pProgressBar = new QProgressBar(this->parent);

      pProgressBar->setStyleSheet("QListWidget{background:rgba(210,240,250,255);color:#19649F;border:0px solid gray;padding:0px -2px 5px 5px;text-align:center;}"
                                    "QListWidget::item{width:94px;height:35px;border:0px solid gray;padding-left:8px;}"
                                    "QListWidget::item:!selected{}"
                                    "QListWidget::item:selected:active{background:#FFFFFF;color:#19649F;border-width:-1;}"
                                    "QListWidget::item:selected{background:#FFFFFF;color:#19649F;}"
                                   );
    pProgressBar->setGeometry(500,500,100,30);
    pProgressBar->setMinimum(0);  // ��Сֵ
    pProgressBar->setMaximum(100);  // ���ֵ
}

void QPlane::advance(int phase)
{
    QString score1 = QString("%1").arg(QBullet::getgore);
    this->label->setText("����:"+score1);

    if(this->blood==30)
    {
        bloodid = 3;
        this->pProgressBar->setValue(100);
    }
    else if(this->blood == 20)
    {
        bloodid  = 2;
        this->pProgressBar->setValue(66);
    }
    else if(this->blood == 10)
    {
        bloodid = 1;
       this->pProgressBar->setValue(33);
    }
    else
    {
        bloodid = 0;
        this->pProgressBar->setValue(1);
    }
}


void QPlane::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawPixmap(-pixmap.width()/2,-pixmap.height(),pixmap);
    if(this->collidingItems().count() > 0)
    {
        doingcollding();
    }
}

void QPlane::been_hit(int harm)
{
    static int i = 0;
    this->blood -= harm;
    qDebug() << "Ѫ��" << blood;

    if(this->blood < 0 )
    {
        //��Ϸ����
        i++;
        mydata = Sqldata::getIstance();
        QSqlDatabase db = Sqldata::getdb();
        QSqlQuery query(db);

        QString S2 =QString("select * from data where name = '%1'").arg(Widget::usernames);
        query.exec(S2);
        if(query.next())
        {
            if(query.value(1).toInt()<QBullet::getgore)
            {
                if(Widget::touristid != 1)
                {
                    QString S1 =QString("update data set score = %1 where name = '%2' ").arg(QBullet::getgore).arg(Widget::usernames);
                    query.exec(S1);
                }
            }
        }
        else
        {
            if(Widget::touristid != 1)
            {
                QString S =QString("insert into data values ('%1','%2');").arg(Widget::usernames).arg(QBullet::getgore);
                query.exec(S);
            }
        }
        gameover = 1;
        qDebug() << "��Ϸ����";

        qDebug()<<QBullet::getgore;
    }
}

void QPlane::doingcollding()
{
    QList<QGraphicsItem*> list = this->collidingItems();
    QList<QGraphicsItem*>::iterator i;

    QBullet *vector;//����һ������
    i = list.begin();
    while(i != list.end())
    {
        vector = (QBullet *)(*i);
        if(vector->item_type== type_e_bullet)//�л��ӵ����ҷ��ɻ�
        {
            //��ըЧ��Bomb
            QBomb *bomb = new QBomb("image/bomb/1.png",this->scene);
            bomb->setPos(mapToScene(0,0).x(),mapToScene(0,0).y());

            this->been_hit(10);
            vector->delebullet();
        }
        i++;
    }
}






