#include "widget.h"
#include "ui_widget.h"
#include "cuipoint.h"
#include "rollingwidget.h"
#include <QDebug>
#include <QTimer>
#include <QPropertyAnimation>
#include <QLabel>
#include <QMovie>
#include <QMessageBox>
#include "sqldata.h"
#include <Qtsql/QSqlDatabase>
#include <Qtsql/QSqlQuery>
#include <stdio.h>

QString Widget::usernames = NULL;   //�˴�������̬����������ȥ
QString Widget::passwords = NULL;
int  Widget::touristid = 0;   //�ο�id

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    GameRankWidget::Rankid = 1;
    touristid = 0;    //�οͱ�־λ ��ʼ��
    this->setFixedSize(600,400);

    //���ش��ڱ߿�
    setWindowFlags(Qt::FramelessWindowHint);
    this->setAutoFillBackground(true);

    //���ñ���ͼƬ
    this->label = new QLabel(this);
    this->label->setGeometry(0,0,600,400);
    this->label->setPixmap(QPixmap("image/bg1_startcg.png"));

    this->setWindowIcon(QIcon("image/icon.png"));
    this->setWindowTitle("����ս��");

    QLabel *plane = new QLabel(this);
    plane->setGeometry(450,50,120,100);
    plane->setPixmap(QPixmap("image/plane_bk.png"));
    plane->show();
    //���ð�ť
 //   this->button = new QPushButton(this);
 //   this->button->setGeometry(50,50,100,100);

    QLabel *label = new QLabel(this);
    QMovie *movie = new QMovie("image/login.gif");
    label->setMovie(movie);
    movie->start();
    label->show();

    //���ñ༭��
    QFont ft;
    ft.setPointSize(25);
    QRegExp rep("[A-Za-z\\w]{1,14}");
    QRegExpValidator *v =new QRegExpValidator(rep,this);
    this->uedit = new QLineEdit(this);
    this->uedit->setGeometry(220,180,200,50);
    this->uedit->setFont(ft);
    this->uedit->setValidator(v);
    this->uedit->setPlaceholderText("�û���");
    this->uedit->setStyleSheet("QWidget{background-color:transparent}");

    QRegExp reps("[0-9]{1,8}");
    QRegExpValidator *a =new QRegExpValidator(reps,this);
    this->pedit = new QLineEdit(this);
    this->pedit->setValidator(a);
    this->pedit->setFont(ft);
    this->pedit->setEchoMode(QLineEdit::Password);
    this->pedit->setGeometry(220,250,200,50);
    this->pedit->setPlaceholderText("����");
    this->pedit->setStyleSheet("QWidget{background-color:transparent}");


    //���ñ�ǩ��
    this->label = new QLabel(this);
    this->label->setGeometry(150,180,50,50);
    this->label->setPixmap(QPixmap("image/user.png"));

    this->label = new QLabel(this);
    this->label->setGeometry(150,250,50,50);
    this->label->setPixmap(QPixmap("image/key.png"));

 //   connect(this->button,SIGNAL(clicked()),this,SLOT(btnclick()));
    //���ð�ť
    this->obutton = new QPushButton(this);
    this->obutton->setIcon(QIcon("image/btn/login.png"));
    this->obutton->setIconSize(QSize(150,46));
    this->obutton->setGeometry(150,320,150,50);
    this->obutton->setFlat(true);
    this->obutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/login2.png);}");

    this->obutton->setShortcut(Qt::Key_Return);   //�س����밴ť���
   // this->obutton->setShortcut(Qt::Key_Enter);

    connect(this->obutton,SIGNAL(clicked()),this,SLOT(SignalTooButton()));


    this->qbutton = new QPushButton(this);
    this->qbutton->setIcon(QIcon("image/btn/exit.png"));
    this->qbutton->setIconSize(QSize(150,46));
    this->qbutton->setGeometry(330,320,150,50);
    this->qbutton->setFlat(true);
    this->qbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/exit2.png);}");

    connect(this->qbutton,SIGNAL(clicked()),this,SLOT(SignalToqButton()));
    this->qbutton->setShortcut(Qt::Key_Escape);

    //ע���˺�
    this->rbutton = new QPushButton(this);
    this->rbutton->setText("ע���˺�");
    this->rbutton->setStyleSheet("QWidget{background-color:transparent}");
    this->rbutton->setGeometry(500,170,70,50);
    this->rbutton->setFlat(true);
    this->rbutton->setStyleSheet("QPushButton:hover{color:rgb(255,0,0);background-color:transparent}");

    connect(this->rbutton,SIGNAL(clicked()),this,SLOT(SignalTorButton()));


    //�һ�����
    this->fbutton = new QPushButton(this);
    this->fbutton->setText("�һ�����");
    this->fbutton->setStyleSheet("QWidget{background-color:transparent}");
    this->fbutton->setGeometry(500,230,70,50);
    this->fbutton->setFlat(true);
    this->fbutton->setStyleSheet("QPushButton:hover{color:rgb(255,0,0);background-color:transparent}");

    connect(this->fbutton,SIGNAL(clicked()),this,SLOT(SignalTofButton()));

    //�һ�����
    this->gbutton = new QPushButton(this);
    this->gbutton->setText("�ο͵�½");
    this->gbutton->setStyleSheet("QWidget{background-color:transparent}");
    this->gbutton->setGeometry(500,200,70,50);
    this->gbutton->setFlat(true);
    this->gbutton->setStyleSheet("QPushButton:hover{color:rgb(255,0,0);background-color:transparent}");

    connect(this->gbutton,SIGNAL(clicked()),this,SLOT(SignalTogButton()));

    this->sbutton = new QPushButton(this);
    this->sbutton->setIcon(QIcon("image/issound.png"));
    this->sbutton->setIconSize(QSize(24,28));
    this->sbutton->setGeometry(510,290,24,28);
    this->sbutton->setFlat(true);
    this->sbutton->setStyleSheet("QPushButton:hover{border-image:url(image/sound.png);}");

    connect(this->sbutton,SIGNAL(clicked()),this,SLOT(StoButton()));
  //  music = new QSound("music/bgm1.wav",this);
    //ע�ᴰ��ʵ����
//    this->rw = new RegWidget(this);
//    rw->hide();

//    //�һ����봰��
//    this->fw = new FindWidget(this);
//    fw->hide();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::btnclick()
{
     QPropertyAnimation *pAnimation = new QPropertyAnimation(this, "pos");
      pAnimation->setDuration(500);
      pAnimation->setLoopCount(2);
      pAnimation->setKeyValueAt(0, QPoint(geometry().x() - 3, geometry().y() - 3));
      pAnimation->setKeyValueAt(0.1, QPoint(geometry().x() + 6, geometry().y() + 6));
      pAnimation->setKeyValueAt(0.2, QPoint(geometry().x() - 6, geometry().y() + 6));
      pAnimation->setKeyValueAt(0.3, QPoint(geometry().x() + 6, geometry().y() - 6));
      pAnimation->setKeyValueAt(0.4, QPoint(geometry().x() - 6, geometry().y() - 6));
      pAnimation->setKeyValueAt(0.5, QPoint(geometry().x() + 6, geometry().y() + 6));
      pAnimation->setKeyValueAt(0.6, QPoint(geometry().x() - 6, geometry().y() + 6));
      pAnimation->setKeyValueAt(0.7, QPoint(geometry().x() + 6, geometry().y() - 6));
      pAnimation->setKeyValueAt(0.8, QPoint(geometry().x() - 6, geometry().y() - 6));
      pAnimation->setKeyValueAt(0.9, QPoint(geometry().x() + 6, geometry().y() + 6));
      pAnimation->setKeyValueAt(1, QPoint(geometry().x() - 3, geometry().y() - 3));
      pAnimation->start(QAbstractAnimation::DeleteWhenStopped);
}

void Widget::SignalTooButton()
{
    int i = 0;
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("db/data.db");
    db.open();

    m_user = this->uedit->text();
    m_psw = this->pedit->text();
    QSqlQuery query(db);
    char buf[2024]="";
    sprintf(buf,"select psw,name from people");
    query.exec(buf);
    qDebug()<<buf;

    if(m_user.count() == 0||m_psw.count()==0)
    {
       btnclick();
        i=3;
        QMessageBox::warning(this,"������ʾ","�˺Ż����벻Ϊ��",QMessageBox::Ok);

    }
    if(i==0)
    {
        while(query.next())
        {
            if(m_user.compare(query.value(1).toString())==0 && m_psw.compare(query.value(0).toString())==0)
            {
                usernames = m_user;   //��ס�˺�  ������������
                passwords = m_psw;
                qDebug()<<usernames;
                qDebug()<<passwords;
                i=1;
               break;
            }
            else
            {
                i=2;
            }
        }
    }
    if(i==1)
    {
        touristid=0;
        //////////////////�����������ݿ���ȡģ��////////////////
        mydata = Sqldata::getIstance();
        QSqlDatabase db = Sqldata::getdb();
        QSqlQuery query(db);
        QString S =QString("select * from people where name='%1'and psw='%2'").arg(usernames).arg(passwords);
        query.exec(S);
        if(query.next())
        {
            qDebug()<<query.value(4).toInt();
            if(query.value(4).toInt()==0)
            {
                QMessageBox message1(QMessageBox::NoIcon,"Welcome","��������,�ո����ӵ��������������ɻ��ƶ���");
                message1.setIconPixmap(QPixmap("image/plane_peek.png"));
//                this->label1 = new QLabel(this);
//                this->label1->setGeometry(0,0,240,360);
//                this->label1->setPixmap(QPixmap("image/032.png"));
//                this->label1->show();

                message1.exec();

            }
        }
        /////////////////////////////////////
        this->uedit->clear();
        this->pedit->clear();
        this->hide();
        CUIPoint::mw->show();
    }
    else if(i==2)
    {
        btnclick();
        QMessageBox::warning(this,"������ʾ","������˻�����",QMessageBox::Ok);
        this->uedit->clear();
        this->pedit->clear();
        this->uedit->setFocus();  //����ƶ����༭��
    }

}

void Widget::SignalToqButton()
{
    if(QMessageBox::Yes==QMessageBox::question(this,"��ʾ","�Ƿ�Ҫ�˳���Ϸ��",QMessageBox::Yes|QMessageBox::No))
    {
        this->close();
    }
}

void Widget::SignalTorButton()
{
    this->close();
    CUIPoint::rw->show();
//    rw->show();
}

void Widget::SignalTofButton()
{
    this->close();
    CUIPoint::fw->show();
    //    fw->show();
}

void Widget::SignalTogButton()
{
    touristid = 1;
    GameRankWidget::Rankid = 1;
    this->hide();
    RollingWidget * rlw = new RollingWidget;
    rlw->show();
}

void Widget::StoButton()
{
    if(true==MenuWidget::music->isFinished())
    {
        MenuWidget::music->play();
        this->sbutton->setIcon(QIcon("image/issound.png"));
    }
    else
    {
        MenuWidget::music->stop();
        this->sbutton->setIcon(QIcon("image/sound.png"));
    }
}

