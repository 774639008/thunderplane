#include "selectwidget.h"
#include "cuipoint.h"
#include "gameview.h"
#include <Qtsql/QSqlDatabase>
#include <Qtsql/QSqlQuery>
#include <QMessageBox>
#include <qDebug>
#include <QVariant>

QString SelectWidget::PlaneName = QString("image/selectplane/1.png");
QString SelectWidget::BulletName = QString("image/selectplane/b1.png");

SelectWidget::SelectWidget(QWidget *parent) :
    QWidget(parent)
{
    //���ñ���ͼƬ
    //���ش��ڱ߿�
    setWindowFlags(Qt::FramelessWindowHint);
    this->setFixedSize(810,489);

    this->label1 = new QLabel(this);
    this->label1->setGeometry(0,0,810,489);
    this->label1->setPixmap(QPixmap("image/stageBg.png"));

    this->setWindowIcon(QIcon("image/icon.png"));
    this->setWindowTitle("����ս��");

    //���ñ�ǩ��
    this->button1 = new QPushButton(this);
    this->button1->setIcon(QIcon("image/selectplane/1.png"));
    this->button1->setIconSize(QSize(150,150));
    this->button1->setGeometry(155,150,150,150);
    this->button1->setFlat(true);
    this->connect(this->button1,SIGNAL(clicked()),this,SLOT(buttonone()));


    this->button2 = new QPushButton(this);
    this->button2->setIcon(QIcon("image/selectplane/2.png"));
    this->button2->setIconSize(QSize(150,150));
    this->button2->setGeometry(335,150,150,150);
    this->button2->setFlat(true);
    this->connect(this->button2,SIGNAL(clicked()),this,SLOT(buttontwo()));


    this->button3 = new QPushButton(this);
    this->button3->setIcon(QIcon("image/selectplane/3.png"));
    this->button3->setIconSize(QSize(150,150));
    this->button3->setGeometry(515,150,150,150);
    this->button3->setFlat(true);
    this->connect(this->button3,SIGNAL(clicked()),this,SLOT(buttonthree()));

    //���ư�ť
    this->obutton = new QPushButton(this);
    this->obutton->setIcon(QIcon("image/btn/ok.png"));
    this->obutton->setFlat(true);
    this->obutton->setIconSize(QSize(142,53));
    this->obutton->setGeometry(150,320,142,53);
    this->obutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");

    connect(this->obutton,SIGNAL(clicked()),this,SLOT(OkButton()));
    this->obutton->setShortcut(Qt::Key_Return);

    this->qbutton = new QPushButton(this);
    this->qbutton->setIcon(QIcon("image/btn/Cancel.png"));
    this->qbutton->setFlat(true);
    this->qbutton->setIconSize(QSize(142,53));
    this->qbutton->setGeometry(480,320,142,53);
    this->qbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/Cancel1.png);}");

    connect(this->qbutton,SIGNAL(clicked()),this,SLOT(QuitButton()));
    this->qbutton->setShortcut(Qt::Key_Escape);
}

void SelectWidget::buttonone()
{
    this->button1->setIcon(QIcon("image/selectplane/11.png"));
    this->button2->setIcon(QIcon("image/selectplane/2.png"));
    this->button3->setIcon(QIcon("image/selectplane/3.png"));
    flag = 1;
}

void SelectWidget::buttontwo()
{
    this->button1->setIcon(QIcon("image/selectplane/1.png"));
    this->button2->setIcon(QIcon("image/selectplane/22.png"));
    this->button3->setIcon(QIcon("image/selectplane/3.png"));
    flag = 2;
}

void SelectWidget::buttonthree()
{
    this->button1->setIcon(QIcon("image/selectplane/1.png"));
    this->button2->setIcon(QIcon("image/selectplane/2.png"));
    this->button3->setIcon(QIcon("image/selectplane/33.png"));
    flag = 3;
}

void SelectWidget::OkButton()
{
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("db/data.db");
    db.open();

    QString test=QString("1");
    QString test2=QString("1");
    if(flag==1)
    {
        PlaneName = QString("image/selectplane/1.png");
    }
    else if(flag == 2)
    {
        PlaneName = QString("image/selectplane/2.png");
    }
    else
    {
        PlaneName = QString("image/selectplane/3.png");
    }
    QString S =QString("select * from myplane where planetype='%1'").arg(PlaneName);
    QSqlQuery query;

    if(query.exec(S)&&query.first())
    {
        BulletName=query.value(2).toString();
        QMessageBox message1(QMessageBox::NoIcon,"Suc","ѡ��ɹ���");
        message1.setIconPixmap(QPixmap("image/plane_peek.png"));
        message1.exec();
    }
    else
    {
        qDebug()<<"false";
    }
}

void SelectWidget::QuitButton()
{
    this->hide();
    CUIPoint::spw->show();
}


