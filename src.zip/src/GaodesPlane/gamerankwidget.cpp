#include "gamerankwidget.h"
#include <vector>
#include <list>
#include <iostream>
#include <QVariant>
#include <QDebug>

using namespace std;

QString GameRankWidget::SceneName = QString("image/map.png");
int GameRankWidget::Rankid = 0;

GameRankWidget::GameRankWidget(QWidget *parent) :
    QWidget(parent)
{
    Rankid = 0;
    flag = 1;
    flag2 = 1;

    //���ش��ڱ߿�
    setWindowFlags(Qt::FramelessWindowHint);
    this->setFixedSize(810,489);
    //���ñ���ͼƬ
    this->label1 = new QLabel(this);
    this->label1->setGeometry(0,0,810,489);
    this->label1->setPixmap(QPixmap("image/gamerank/gamerank.png"));

    this->setWindowIcon(QIcon("image/icon.png"));
    this->setWindowTitle("����ս��");

    //���ñ�ǩ��
    this->label2 = new QLabel(this);
    this->label2->setGeometry(325,50,100,50);
    this->label2->setPixmap(QPixmap("image/gamerank/tab-easy.png"));
    this->label2->setScaledContents(true);

    this->label3 = new QLabel(this);
    this->label3->setGeometry(300,100,150,100);
    this->label3->setPixmap(QPixmap("image/gamerank/map1.png"));
    this->label3->setScaledContents(true);



    this->okbutton = new QPushButton(this);
    this->okbutton->setIcon(QIcon("image/btn/ok.png"));
    this->okbutton->setFlat(true);
    this->okbutton->setIconSize(QSize(142,53));
    this->okbutton->setGeometry(150,320,142,53);
    this->okbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");

    connect(this->okbutton,SIGNAL(clicked()),this,SLOT(OkbuttonClick()));
    this->okbutton->setShortcut(Qt::Key_Return);

    this->qbutton = new QPushButton(this);
    this->qbutton->setIcon(QIcon("image/btn/Cancel.png"));
    this->qbutton->setFlat(true);
    this->qbutton->setIconSize(QSize(142,53));
    this->qbutton->setGeometry(480,320,142,53);
    this->qbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/Cancel1.png);}");

    connect(this->qbutton,SIGNAL(clicked()),this,SLOT(QbuttonClcik()));
    this->qbutton->setShortcut(Qt::Key_Escape);


    this->nextbutton = new QPushButton(this);
    this->nextbutton->setIcon(QIcon("image/gamerank/left.png"));
    this->nextbutton->setFlat(true);
    this->nextbutton->setIconSize(QSize(125,125));
    this->nextbutton->setGeometry(150,100,125,125);
    this->nextbutton->setStyleSheet("QPushButton:hover{border-image:url(image/gamerank/left.png);}");

    connect(this->nextbutton,SIGNAL(clicked()),this,SLOT(PrebuttonClick()));

    this->prebutton = new QPushButton(this);
    this->prebutton->setIcon(QIcon("image/gamerank/right.png"));
    this->prebutton->setFlat(true);
    this->prebutton->setIconSize(QSize(125,125));
    this->prebutton->setGeometry(480,100,125,125);
    this->prebutton->setStyleSheet("QPushButton:hover{border-image:url(image/gamerank/right.png);}");

    connect(this->prebutton,SIGNAL(clicked()),this,SLOT(NextbuttonClick()));

}

void GameRankWidget::NextbuttonClick()
{
    //���ñ�־λ
    int i = 0;
    int j = 0;
    flag++;
    flag2++;
    if(flag==4)
    {
        flag = 1;
    }
    if(flag2==4)
    {
        flag2 = 1;
    }
    //
    list<QString> Link;     //װ ��Ϸ����
    list<QString> Link2;    //װ ��Ϸ�Ѷȱ�ʶ
    mydata = Sqldata::getIstance();
    QSqlDatabase db = Sqldata::getdb();
    QSqlQuery query(db);
    QString S1 =QString("select * from gamerank");
    query.exec(S1);
    while(query.next())
    {
        QString l = query.value(0).toString();
        QString r = query.value(1).toString();
        Link.push_back(l);
        Link2.push_back(r);

    }
    //����������Ϸ�����ǩ
    list<QString>::iterator p = Link.begin();
    while( p!=Link.end())
    {
        i++;
        if(i==flag)
        {
            temp = QString(*p);
            this->label3->setPixmap(QPixmap("image/gamerank/"+*p));
    //        SceneName = QString("image/gamerank/"+*p);
            qDebug()<<"image/gamerank/"+*p;
        }

        p++;
    }
    //����������Ϸ�Ѷȱ�ǩ
    list<QString>::iterator p1 = Link2.begin();
    while(p1!=Link2.end())
    {
       j++;
       if(j==flag2)
       {
           temp2 = QString(*p1);
           this->label2->setPixmap(QPixmap("image/gamerank/"+*p1));
           qDebug()<<"image/gamerank/"+*p1;
       }
       p1++;
    }
}

void GameRankWidget::PrebuttonClick()
{
    //���ñ�־λ
    int i = 0;
    int j = 0;
    flag++;
    flag2++;
    if(flag==4)
    {
        flag = 1;
    }
    if(flag2==4)
    {
        flag2 = 1;
    }
    //
    list<QString> Link;     //װ ��Ϸ����
    list<QString> Link2;    //װ ��Ϸ�Ѷȱ�ʶ
    mydata = Sqldata::getIstance();
    QSqlDatabase db = Sqldata::getdb();
    QSqlQuery query(db);
    QString S1 =QString("select * from gamerank");
    query.exec(S1);
    while(query.next())
    {
        QString l = query.value(0).toString();
        QString r = query.value(1).toString();
        Link.push_back(l);
        Link2.push_back(r);
    }
    //����������Ϸ�����ǩ
    list<QString>::reverse_iterator p = Link.rbegin();
    while( p!=Link.rend())
    {
        i++;
        if(i==flag)
        {
            temp = QString(*p);
            this->label3->setPixmap(QPixmap("image/gamerank/"+*p));
            qDebug()<<"image/gamerank/"+*p;
        }

        p++;
    }
    //����������Ϸ�Ѷȱ�ǩ
    list<QString>::reverse_iterator p1 = Link2.rbegin();
    while(p1!=Link2.rend())
    {
       j++;
       if(j==flag2)
       {
           temp2 = QString(*p1);
           this->label2->setPixmap(QPixmap("image/gamerank/"+*p1));
           qDebug()<<"image/gamerank/"+*p1;
       }
       p1++;
    }

}

void GameRankWidget::OkbuttonClick()
{
    SceneName = QString("image/gamerank/"+temp);
    if(SceneName.compare("image/gamerank/map1.png") == 0)
    {
        Rankid = 1;    //�Ѷȱ�־λ
    }
    else if(SceneName.compare("image/gamerank/map2.jpg") == 0)
    {
        qDebug()<<"rankid=2";
        Rankid = 2;
    }
    else if(SceneName.compare("image/gamerank/map3.jpg")==0)
    {
        Rankid = 3;
    }

    QMessageBox message1(QMessageBox::NoIcon,"tip","ѡ��ɹ�����");
    message1.setIconPixmap(QPixmap("image/plane_peek.png"));
    message1.exec();
}

void GameRankWidget::QbuttonClcik()
{
    this->hide();
    CUIPoint::spw->show();
}
