#ifndef ROLLINGWIDGET_H
#define ROLLINGWIDGET_H

#include <QWidget>
#include <QIcon>
#include "gameview.h"
#include "sqldata.h"
#include "widget.h"
#include "gamerankwidget.h"
#include <QParallelAnimationGroup>

class RollingWidget : public QWidget
{
    Q_OBJECT
public:
    explicit RollingWidget(QWidget *parent = 0);
    static int retime;  //��Ϸ����ʱ���λ
  //  static int destroy; //ɾ�����Լ����λ
    ~RollingWidget();
    QParallelAnimationGroup *group1;
signals:

public slots:

private:
    GameView *gameview;
    Sqldata *mydata;

};

#endif // ROLLINGWIDGET_H
