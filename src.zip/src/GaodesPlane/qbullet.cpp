#include "qbullet.h"
#include <QGraphicsItem>
#include "qenemy.h"
#include "qDebug"
#include "qenemy.h"
#include "qbomb.h"

int QBullet::getgore = 0;

QBullet::QBullet(const QString &filename,QGraphicsScene *scene,int i_type):PixmapItem(filename,scene)
{
  //  this->scene = scene;
  //  this->plane = plane;
    this->item_type = i_type;
    this->scene = scene;
   // this->flag = 40;

  //  this->setPos(plane->pos().x(),plane->pos().y()-100);
}

void QBullet::advance(int phase)
{
    if(mapToScene(0,0).x()<=0||mapToScene(0,0).x()>=800||mapToScene(0,0).y()<=0)
    {
        delete this;
    }
    else
    {
        //�ӵ�ǰ��
        if(type_m_bullet == item_type) //�ҷ��ӵ�
        {
            this->setPos(mapToScene(0,-10));
        }
        else//�л��ӵ�
        {
            this->setPos(mapToScene(0,5));
        }
    }



}

void QBullet::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{

        painter->drawPixmap(-pixmap.width()/2,-pixmap.height(),pixmap);
//        if(this->collidingItems().count() > 0)
//        {
//            getscore();
//        }

}

void QBullet::getscore()
{
//    if(this->collidingItems().count() > 0)
//    {
//        QList<QGraphicsItem*> list = this->collidingItems();
//        QList<QGraphicsItem*>::iterator i;

//        QEnemy *vector;//����һ������
//        i = list.begin();
//        while(i != list.end())
//        {
//            vector = (QEnemy *)(*i);
//            if(vector->item_type == type_myplane && this->item_type == type_e_bullet)//�л��ӵ����ҷ��ɻ�
//            {
//                qDebug() << "�ҷ��ɻ�������";
//                QPlane *plane;
//                plane = (QPlane *)(vector);
//                plane->been_hit(10);
//                i++;

//                //��ըЧ��Bomb
//                this->bomb = new QBomb("image/bomb/1.png",this->scene);
//                bomb->setPos(mapToScene(0,0).x(),mapToScene(0,0).y()-50);
//                if(i == list.end())
//                {
//                    qDebug()<<"ss";
//                    this->setPos(1000,1000);
//                    // delete this;//ɾ������ӵ�
//                }
//                continue;
//            }
//            else if(vector->item_type == type_enemy && this->item_type == type_m_bullet) //�ҷ��ӵ���л�
//            {
//                qDebug() << "ɾ���л�";
//                getgore++;
//                i++;

//              //  ��ըЧ��Bomb
//                this->bomb = new QBomb("image/bomb/1.png",this->scene);
//                bomb->setPos(mapToScene(0,0).x(),mapToScene(0,0).y()-100);
//                if(i == list.end())
//                {
//                    delete this;//ɾ������ӵ�
//                    vector->setPos(1000,100);
//                }
//                continue;
//            }
//            i++;
//          //  qDebug() << "����" << item_type;
//        }
//    }
}

void QBullet::delebullet()
{
    getgore++;
    this->hide();
}

