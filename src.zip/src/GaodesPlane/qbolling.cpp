#include "qbolling.h"
#include "qenemy.h"

QBolling::QBolling(const QString &filename,QGraphicsScene *scene):PixmapItem(filename,scene)
{
    pixmap.load(filename);
    this->scene =scene;
    this->scene->addItem(this);
    this->item_type = type_boss;
}

void QBolling::advance(int phase)
{

}

void QBolling::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
     painter->drawPixmap(-pixmap.width()/2,-pixmap.height(),pixmap.width(),pixmap.height(),pixmap);

}

QRectF QBolling::boundingRect() const
{
    return QRectF(-pixmap.width()/2,-pixmap.height(),pixmap.width(),pixmap.height());
}
