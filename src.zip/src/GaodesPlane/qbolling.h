#ifndef QBOLLING_H
#define QBOLLING_H

#include "pixmapitem.h"

class QBolling : public PixmapItem
{
public:
    QBolling(const QString &filename,QGraphicsScene *scene);
    virtual QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    void advance(int phase);
    QGraphicsScene *scene;
    QPixmap pixmap;
    int flag;
};

#endif // QBOLLING_H
