#include "mydialog.h"
#include "cuipoint.h"

int mydialog::dflag = 0;

mydialog::mydialog(const QString &filename,QWidget *parent) :
    QWidget(parent)
{
    dflag = 0;
    this->setFixedSize(400,400);

    //���ش��ڱ߿�
    setWindowFlags(Qt::FramelessWindowHint);
    this->setAutoFillBackground(true);

    //���ñ���ͼƬ
    this->label = new QLabel(this);
    this->label->setGeometry(0,0,400,400);
    this->label->setPixmap(QPixmap(filename));


    this->okbutton = new QPushButton(this);
    this->okbutton->setIcon(QIcon("image/btn/ok.png"));
    this->okbutton->setFlat(true);
    this->okbutton->setIconSize(QSize(142,53));
    this->okbutton->setGeometry(50,200,142,53);
    this->okbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");
    connect(this->okbutton,SIGNAL(clicked()),this,SLOT(OkLink()));

    this->qbutton = new QPushButton(this);
    this->qbutton->setIcon(QIcon("image/btn/Cancel.png"));
    this->qbutton->setFlat(true);
    this->qbutton->setIconSize(QSize(142,53));
    this->qbutton->setGeometry(240,200,142,53);
    this->qbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/Cancel1.png);}");
    connect(this->qbutton,SIGNAL(clicked()),this,SLOT(QLink()));
}

void mydialog::OkLink()
{
    this->hide();
    dflag = 2;

}

void mydialog::QLink()
{
    dflag = 1;
    this->hide();
}
