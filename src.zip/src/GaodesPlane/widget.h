#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include "regwidget.h"
#include "findwidget.h"
#include "sqldata.h"
#include "QSound"

namespace Ui {
    class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
    static QString usernames;
    static QString passwords;
    static int  touristid;
    void btnclick();
public slots:

    void SignalTooButton();
    void SignalToqButton();
    void SignalTorButton();
    void SignalTofButton();
    void SignalTogButton();
    void StoButton();

private:
    Ui::Widget *ui;
    QPixmap pix;
    QPalette pal;
    QLabel *plane;
    QPushButton *button;
    QLabel *label;
    QLineEdit *uedit;
    QLineEdit *pedit;
    QPushButton *obutton;
    QPushButton *qbutton;
    QString m_user;
    QString m_psw;
    QPushButton *fbutton;
    QPushButton *rbutton;
    RegWidget *rw;
    FindWidget *fw;
    QPushButton *gbutton;
    QPushButton *ubutton;
    QPushButton *sbutton;
    Sqldata *mydata;
    QLabel *label1;
    QPushButton *ebutton;
};

#endif // WIDGET_H
