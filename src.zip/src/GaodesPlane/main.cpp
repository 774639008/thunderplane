#include <QtGui/QApplication>
#include <QTextCodec>
#include <Qtsql/QSqlDatabase>
#include <Qtsql/QSqlQuery>
#include "widget.h"
#include "cuipoint.h"
#include "sqldata.h"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("system"));

    //������
    Widget w;
    w.show();
    CUIPoint *cui=new CUIPoint();
    //test
    sqldataplace = "db/data.db";


//   CUIPoint::mw->show();
    return a.exec();
}
