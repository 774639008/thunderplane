#include "regwidget.h"
#include "cuipoint.h"
#include <QIcon>
#include <QMovie>
#include <QApplication>
#include <QMessageBox>
#include "sqldata.h"

RegWidget::RegWidget(QWidget *parent) :
    QWidget(parent)
{
    setWindowFlags(Qt::FramelessWindowHint);

    this->setFixedSize(600,400);


    this->label = new QLabel(this);
    this->label->setGeometry(0,0,600,400);
    this->label->setPixmap(QPixmap("image/bg2_startcg.png"));

    this->setWindowIcon(QIcon("image/icon.png"));
    this->setWindowTitle("����ս��");

    //�����ܱ�����
    //ʵ�� QComboBox
    this->comboBox = new QComboBox(this);
    //�ؼ���ʾλ�ô�С
    comboBox->setGeometry(QRect(200,240,180,25));

    //�����ַ����б�
    QStringList str;
    str << "���������Ǽ��¼���" << "���ĸ������ֽ�ʲô" << "����ĸ�����ֽ�ʲô";
    //���ַ����б��� QComboBox �ؼ�
    comboBox->addItems(str);
    comboBox->show();


    //���ñ�ǩ��
    this->UserName = new QLabel(this);
    this->UserName->setGeometry(150,80,50,50);
    this->UserName->setPixmap(QPixmap("image/user.png"));

    this->Password = new QLabel(this);
    this->Password->setGeometry(150,130,50,50);
    this->Password->setPixmap(QPixmap("image/user.png"));

    this->RePassword = new QLabel(this);
    this->RePassword->setGeometry(150,180,50,50);
    this->RePassword->setPixmap(QPixmap("image/user.png"));

    this->ProTected = new QLabel(this);
    this->ProTected->setGeometry(150,230,50,50);
    this->ProTected->setPixmap(QPixmap("image/user.png"));

    //�༭��
    QRegExp rep("[a-zA-Z\\w]{1,14}");
    QRegExpValidator *v =new QRegExpValidator(rep,this);
    this->UserNameText = new QLineEdit(this);
    this->UserNameText->setGeometry(200,87,180,25);
    this->UserNameText->setValidator(v);
    this->UserNameText->setPlaceholderText("�û���");


    QRegExp rep1("[0-9]{1,8}");
    QRegExpValidator *v2 =new QRegExpValidator(rep1,this);
    this->PasswordText = new QLineEdit(this);
    this->PasswordText->setGeometry(200,137,180,25);
    this->PasswordText->setValidator(v2);
    this->PasswordText->setPlaceholderText("����");
    this->PasswordText->setEchoMode(QLineEdit::Password);

    this->RePasswordText = new QLineEdit(this);
    this->RePasswordText->setGeometry(200,187,180,25);
    this->RePasswordText->setValidator(v2);
    this->RePasswordText->setPlaceholderText("ȷ������");
    this->RePasswordText->setEchoMode(QLineEdit::Password);

    this->ProTectedText = new QLineEdit(this);
    this->ProTectedText->setGeometry(200,282,180,25);
    this->ProTectedText->setValidator(v);
    this->ProTectedText->setPlaceholderText("�ܱ���");

    //���ư�ť
    this->obutton = new QPushButton(this);
    this->obutton->setIcon(QIcon("image/btn/ok.png"));
    this->obutton->setFlat(true);
    this->obutton->setIconSize(QSize(142,53));
    this->obutton->setGeometry(150,320,142,53);
    this->obutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");

    connect(this->obutton,SIGNAL(clicked()),this,SLOT(RSignalTooButton()));
    this->obutton->setShortcut(Qt::Key_Return);

    this->qbutton = new QPushButton(this);
    this->qbutton->setIcon(QIcon("image/btn/Cancel.png"));
    this->qbutton->setFlat(true);
    this->qbutton->setIconSize(QSize(142,53));
    this->qbutton->setGeometry(330,320,142,53);
    this->qbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/Cancel1.png);}");

    connect(this->qbutton,SIGNAL(clicked()),this,SLOT(RSignalToqButton()));
    this->qbutton->setShortcut(Qt::Key_Escape);
}

void RegWidget::RSignalTooButton()
{
    mydata = Sqldata::getIstance();

    QString UName = UserNameText->text();
    QString Pword;
    QString Question;
    QString Qid;
    QString Again = QString("0");

    if(UserNameText->text().count()!=0&&PasswordText->text()==RePasswordText->text()&&PasswordText->text().count()!=0)
    {
        if(comboBox->currentText().compare("���������Ǽ��¼���")==0)
        {
            Qid = QString("1");
        }else if(comboBox->currentText().compare("���ĸ������ֽ�ʲô")==0)
        {
            Qid = QString("2");
        }else if(comboBox->currentText().compare("����ĸ�����ֽ�ʲô")==0)
        {
            Qid = QString("3");
        }
        Question = ProTectedText->text();
        Pword = PasswordText->text();
        QString i=QString("insert into people values ('%1','%2','%3','%4','%5'); ").arg(UName).arg(Pword).arg(Question).arg(Qid).arg(Again);
        QString S =QString("select * from people where name='%1' ").arg(UName);
        QSqlQuery query;
        if(query.exec(S)&&query.first())
        {
            QMessageBox message(QMessageBox::NoIcon,"Error","�û����ظ��������ԣ�����");
            message.setIconPixmap(QPixmap("image/g_logo_cp.png"));
            message.exec();
        }
        else if(query.exec(i))
        {
            QMessageBox message1(QMessageBox::NoIcon,"Error","ע��ɹ�������");
            message1.setIconPixmap(QPixmap("image/plane_peek.png"));
            message1.exec();
            this->UserNameText->clear();
            this->PasswordText->clear();
            this->RePasswordText->clear();
            this->ProTectedText->clear();
        }
        else
        {
            QMessageBox message2(QMessageBox::NoIcon,"Error","ע��ʧ�ܣ������ԣ�����");
            message2.setIconPixmap(QPixmap("image/g_logo_cp.png"));
            message2.exec();
        }

        this->close();
        CUIPoint::w->show();
    }
    else if(UserNameText->text().count() == 0||PasswordText->text().count()==0||RePasswordText->text().count()==0||ProTectedText->text().count()==0)
        QMessageBox::warning(NULL,"Error","����д������Ϣ������");
    else
        QMessageBox::warning(NULL,"Error","���벻�ظ��������ԣ�����");
    this->UserNameText->clear();
    this->PasswordText->clear();
    this->RePasswordText->clear();
    this->ProTectedText->clear();
}

void RegWidget::RSignalToqButton()
{
    this->close();
    CUIPoint::w->show();
}


