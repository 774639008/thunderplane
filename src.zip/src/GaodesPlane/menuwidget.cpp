#include "menuwidget.h"
#include "cuipoint.h"
#include "myrankwidget.h"
#include <QMessageBox>
#include <QDebug>

QSound * MenuWidget::music = NULL;

MenuWidget::MenuWidget(QWidget *parent) :
    QWidget(parent)
{

    this->setAutoFillBackground(true);
    //���ش��ڱ߿�
    setWindowFlags(Qt::FramelessWindowHint);
    this->setFixedSize(810,489);

  //  setWindowFlags(Qt::FramelessWindowHint);

    //���ñ���ͼƬ
    this->label = new QLabel(this);
    this->label->setGeometry(0,0,810,489);
    this->label->setPixmap(QPixmap("image/cg3.jpg"));

    this->setWindowIcon(QIcon("image/icon.png"));
    this->setWindowTitle("����ս��");


    //���ñ�ǩ��
//    this->label = new QLabel(this);
//    this->label->setGeometry(320,50,200,50);
//    this->label->setPixmap(QPixmap("image/btn/startgame.png"));

//    this->label = new QLabel(this);
//    this->label->setGeometry(320,100,200,50);
//    this->label->setPixmap(QPixmap("image/btn/plane_choose.png"));

    this->bbutton = new QPushButton(this);
    this->bbutton->setIcon(QIcon("image/btn/startgame.png"));
    this->bbutton->setFlat(true);
    this->bbutton->setIconSize(QSize(142,53));
    this->bbutton->setGeometry(320,80,150,50);
    this->bbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");
    connect(this->bbutton,SIGNAL(clicked()),this,SLOT(btoclick()));

    this->rbutton = new QPushButton(this);
    this->rbutton->setIcon(QIcon("image/btn/ranklist.png"));
    this->rbutton->setFlat(true);
    this->rbutton->setIconSize(QSize(142,53));
    this->rbutton->setGeometry(320,160,150,50);
    this->rbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");
    connect(this->rbutton,SIGNAL(clicked()),this,SLOT(rtoclick()));

    this->tbutton = new QPushButton(this);
    this->tbutton->setIcon(QIcon("image/btn/setup.png"));
    this->tbutton->setFlat(true);
    this->tbutton->setIconSize(QSize(142,53));
    this->tbutton->setGeometry(320,240,150,50);
    this->tbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");
    connect(this->tbutton,SIGNAL(clicked()),this,SLOT(ttoclick()));

    this->hbutton = new QPushButton(this);
    this->hbutton->setIcon(QIcon("image/btn/help.png"));
    this->hbutton->setFlat(true);
    this->hbutton->setIconSize(QSize(142,53));
    this->hbutton->setGeometry(320,320,150,50);
    this->hbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");
    connect(this->hbutton,SIGNAL(clicked()),this,SLOT(htoclick()));

    this->qbutton = new QPushButton(this);
    this->qbutton->setIcon(QIcon("image/btn/logout.png"));
    this->qbutton->setFlat(true);
    this->qbutton->setIconSize(QSize(142,53));
    this->qbutton->setGeometry(320,400,150,50);
    this->qbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");
    connect(this->qbutton,SIGNAL(clicked()),this,SLOT(qtoclick()));
    this->qbutton->setShortcut(Qt::Key_Escape);

    music = new QSound("music/bgm1.wav",this);
    music->setLoops(-1);
    music->play();


}

void MenuWidget::rtoclick()
{
    this->hide();
//    RankWidget * rkw = new RankWidget;
//    rkw->show();
   // CUIPoint::mrk->show();
    MyrankWidget *mrk = new MyrankWidget;
    mrk->show();

}

void MenuWidget::ttoclick()
{
    this->hide();
    CUIPoint::spw->show();
}

void MenuWidget::btoclick()
{
    this->hide();
    this->rlw = new RollingWidget;
    rlw->show();
}

void MenuWidget::qtoclick()
{
    if(QMessageBox::Yes==QMessageBox::question(this,"��ʾ","�Ƿ�ע���û�",QMessageBox::Yes|QMessageBox::No))
    {
        this->hide();
        CUIPoint::w->show();
    }
}

void MenuWidget::htoclick()
{
    this->tbutton->hide();
    this->qbutton->hide();
    this->hbutton->hide();
    this->bbutton->hide();
    this->rbutton->hide();
    this->label1 = new QLabel(this);
    this->label1->setGeometry(160,50,451,429);
    this->label1->setPixmap(QPixmap("image/help.png"));
    this->label1->show();

    this->ebutton = new QPushButton(this);
    this->ebutton->setIcon(QIcon("image/false.png"));
    this->ebutton->setFlat(true);
    this->ebutton->setIconSize(QSize(48,47));
    this->ebutton->setGeometry(550,100,48,47);
    this->ebutton->setStyleSheet("QPushButton:hover{border-image:url(image/false.png);}");
    connect(this->ebutton,SIGNAL(clicked()),this,SLOT(etoclick()));
    this->ebutton->show();
    this->ebutton->setShortcut(Qt::Key_Escape);
}

void MenuWidget::etoclick()
{
    qDebug()<<"2222";
    this->tbutton->show();
    this->qbutton->show();
    this->hbutton->show();
    this->bbutton->show();
    this->rbutton->show();
    this->ebutton->hide();
    this->label->show();
    this->label1->hide();
}
