#ifndef CUIPOINT_H
#define CUIPOINT_H

#include "regwidget.h"
#include "findwidget.h"
#include "widget.h"
#include "menuwidget.h"
#include "rankwidget.h"
#include "setupwidget.h"
#include "sqldata.h"
#include "rollingwidget.h"
#include "selectwidget.h"
#include "gamerankwidget.h"

class CUIPoint
{
public:
    CUIPoint();
    static class FindWidget * fw;
    static class RegWidget * rw;
    static class Widget * w;
    static class MenuWidget *mw;
//  static class RankWidget *rkw;
    static class SetupWidget *spw;
//  static class RollingWidget *rlw;
    static class SelectWidget *sw;
    static class GameRankWidget *gw;
//  static class MyrankWidget *mrk;
};

#endif // CUIPOINT_H
