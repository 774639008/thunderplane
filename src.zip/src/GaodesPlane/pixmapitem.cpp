#include "pixmapitem.h"
#include "qenemy.h"

PixmapItem::PixmapItem(const QString &filename,QGraphicsScene *scene)
{
    pixmap.load(filename);
//    this->scene =scene;
//    this->scene->addItem(this);
    scene->addItem(this);
}

QRectF PixmapItem::boundingRect() const
{
    return QRectF(-pixmap.width()/2,-pixmap.height(),pixmap.width(),pixmap.height());
}

void PixmapItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawPixmap(-pixmap.width()/2,-pixmap.height(),pixmap.width(),pixmap.height(),pixmap);
}

//void PixmapItem::advance(int phase)
//{

//}
