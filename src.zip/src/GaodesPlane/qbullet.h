#ifndef QBULLET_H
#define QBULLET_H

#include <QGraphicsScene>
#include "pixmapitem.h"
#include "qplane.h"
#include "qbomb.h"

class QBullet: public PixmapItem
{
public:
    QBullet(const QString &filename,QGraphicsScene *scene,int i_type);
    void advance(int phase);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    void getscore();
    void delebullet();
    static int getgore;
    QBomb *bomb;
};

#endif // QBULLET_H
