#ifndef REGWIDGET_H
#define REGWIDGET_H

#include "sqldata.h"
#include <QWidget>
#include <QLabel>
#include <QComboBox>
#include <QLineEdit>
#include <QPushButton>
#include <Qtsql/QSqlDatabase>
#include <Qtsql/QSqlQuery>


class RegWidget : public QWidget
{
    Q_OBJECT
public:
    explicit RegWidget(QWidget *parent = 0);

signals:

public slots:
    void RSignalTooButton();
    void RSignalToqButton();
private:
    QLabel *label;
    QLabel *name;
    QLabel *psw;
    QComboBox *comboBox;
    QLineEdit *lineEdit;
    QLabel *UserName;
    QLabel *Password;
    QLabel *RePassword;
    QLabel *ProTected;
    QLineEdit *UserNameText;
    QLineEdit *PasswordText;
    QLineEdit *RePasswordText;
    QLineEdit *ProTectedText;
    QPushButton *obutton;
    QPushButton *qbutton;
    QSqlDatabase db;
    Sqldata *mydata;
};

#endif // REGWIDGET_H
