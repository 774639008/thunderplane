#include "sqldata.h"

Sqldata *Sqldata::instance;
QSqlDatabase Sqldata::db;

Sqldata::Sqldata(QWidget *parent) :
    QWidget(parent)
{
    db=QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("db/data.db");
    db.open();
}

Sqldata * Sqldata::getIstance()
{
    QMutex muttex;
    if(instance == NULL)
    {
        muttex.lock();
        if(instance == NULL)
        {
            instance = new Sqldata();
        }
        muttex.unlock();
    }
    return instance;
}

QSqlDatabase  Sqldata::getdb()
{
    return db;
}
