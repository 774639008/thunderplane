#include "rankwidget.h"
#include "cuipoint.h"
#include <Qtsql/QSqlDatabase>
#include <Qtsql/QSqlQuery>
#include <QDebug>
#include <QVariant>
#include <QTableWidget>
#include <QScrollBar>
#include <QSqlQueryModel>

static int nCurScroller=0; //��ҳʱ�ĵ�ʱ������λ��
static int pageValue = 10; // һҳ��ʾ����(����-1)

RankWidget::RankWidget(QWidget *parent) :
    QWidget(parent)
{

    //���������С
    QFont ft;
    ft.setPointSize(10);

    //���ش��ڱ߿�
    setWindowFlags(Qt::FramelessWindowHint);
    this->setFixedSize(600,400);
    //���ñ���ͼƬ
    this->label = new QLabel(this);
    this->label->setGeometry(0,0,600,400);
    this->label->setPixmap(QPixmap("image/rankbg.png"));

    this->setWindowIcon(QIcon("image/icon.png"));
    this->setWindowTitle("����ս��");



    this->prebutton = new QPushButton(this);
    this->prebutton->setText("��һҳ");
    this->prebutton->setFont(ft);
    this->prebutton->setStyleSheet("QWidget{background-color:transparent}");
    this->prebutton->setGeometry(200,350,50,30);
    this->prebutton->setFlat(true);
    this->prebutton->setStyleSheet("QPushButton:hover{color:rgb(255,0,0);background-color:transparent}");
    connect(this->prebutton,SIGNAL(clicked()),this,SLOT(PretoSignal()));


    this->rbutton = new QPushButton(this);
    this->rbutton->setText("����");
    this->rbutton->setFont(ft);
    this->rbutton->setStyleSheet("QWidget{background-color:transparent}");
    this->rbutton->setGeometry(285,350,50,30);
    this->prebutton->setFlat(true);
    this->rbutton->setStyleSheet("QPushButton:hover{color:rgb(255,0,0);background-color:transparent}");
    connect(this->rbutton,SIGNAL(clicked()),this,SLOT(RtoSignal()));
    this->rbutton->setShortcut(Qt::Key_Escape);

    this->nextbutton = new QPushButton(this);
    this->nextbutton->setText("��һҳ");
    this->nextbutton->setFont(ft);
    this->nextbutton->setStyleSheet("QWidget{background-color:transparent}");
    this->nextbutton->setGeometry(370,350,50,30);
    this->nextbutton->setFlat(true);
    this->nextbutton->setStyleSheet("QPushButton:hover{color:rgb(255,0,0);background-color:transparent}");
    connect(this->nextbutton,SIGNAL(clicked()),this,SLOT(NexttoSignal()));

    mydata = Sqldata::getIstance();
    QSqlDatabase db = Sqldata::getdb();
    QSqlQuery query(db);
    char buf[2024]="";
    strcpy(buf,"select * from data order by score DESC");
    query.exec(buf);
    QSqlQueryModel *mode = new QSqlQueryModel(this);
    mode->setQuery("select * from data order by score DESC");
    mode->setHeaderData(0,Qt::Horizontal,tr("score"));
    mode->setHeaderData(1,Qt::Horizontal,tr("name"));


    this->view = new QTableView(this);
    view->setEditTriggers(QAbstractItemView::NoEditTriggers);
    view->setGeometry(200,0,230,340);
   // view->setStyleSheet("QWidget{background-color:transparent}");

    view->setModel(mode);

}

void RankWidget::NexttoSignal()
{
    int maxValue = view->verticalScrollBar()->maximum();
    int nCurScroller = view->verticalScrollBar()->value();
    if(nCurScroller<maxValue)
        view->verticalScrollBar()->setSliderPosition(pageValue+nCurScroller);
    else
        view->verticalScrollBar()->setSliderPosition(0);
}

void RankWidget::PretoSignal()
{
    int maxValue = view->verticalScrollBar()->maximum(); // ��ǰSCROLLER�����ʾֵ25
    int nCurScroller = view->verticalScrollBar()->value();

    if(nCurScroller>0)
        view->verticalScrollBar()->setSliderPosition(nCurScroller-pageValue);
    else
        view->verticalScrollBar()->setSliderPosition(maxValue);
}

void RankWidget::RtoSignal()
{
    this->hide();
    CUIPoint::mw->show();
}
