#ifndef PIXMAPITEM_H
#define PIXMAPITEM_H

#include <QGraphicsItem>
#include <QPixmap>
#include <QPainter>
#include <QGraphicsScene>


enum e_type
{
    type_myplane =  1,
    type_wing   =   2,
    type_tail   =   3,
    type_enemy   =  4,
    type_e_bullet = 5,
    type_m_bullet = 6,
    type_bomb   =   7,
    type_boss   =   8,
    type_blood  =   9

};

class PixmapItem : public QGraphicsItem
{
public:
    PixmapItem(const QString &filename,QGraphicsScene *scene);
    virtual QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
//    void advance(int phase);
    QGraphicsScene *scene;
    QPixmap pixmap;
    int flag;
    int item_type;
};

#endif // PIXMAPITEM_H
