#ifndef MENUWIDGET_H
#define MENUWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QIcon>
#include <QPushButton>
#include <QSound>
#include "rollingwidget.h"

class MenuWidget : public QWidget
{
    Q_OBJECT
public:
    explicit MenuWidget(QWidget *parent = 0);
//    static int g;
    static QSound *music;

    class RollingWidget * func()
    {
       return rlw;
    }
signals:

public slots:
    void btoclick();
    void rtoclick();
    void ttoclick();
    void qtoclick();
    void htoclick();
    void etoclick();


private:
    QLabel *label;
    QLabel *label1;
    QPushButton *bbutton;
    QPushButton *rbutton;
    QPushButton *tbutton;
    QPushButton *hbutton;
    QPushButton *qbutton;
    QPushButton *ebutton;
    RollingWidget * rlw;
};

#endif // MENUWIDGET_H
