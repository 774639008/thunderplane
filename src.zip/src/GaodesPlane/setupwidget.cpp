#include "setupwidget.h"
#include "cuipoint.h"
#include <qDebug>


SetupWidget::SetupWidget(QWidget *parent) :
    QWidget(parent)
{
    //Ĭ����������Ϊ��
    newflag = true;

    //���ش��ڱ߿�
    setWindowFlags(Qt::FramelessWindowHint);
    this->setFixedSize(810,489);

    //���ñ���ͼƬ
    this->label = new QLabel(this);
    this->label->setGeometry(0,0,810,489);
    this->label->setPixmap(QPixmap("image/setupbg.png"));

    this->setWindowIcon(QIcon("image/icon.png"));
    this->setWindowTitle("����ս��");

    //���ư�ť
    //ѡ��ɻ���ť
    this->sbutton = new QPushButton(this);
    this->sbutton->setIcon(QIcon("image/btn/plane_choose.png"));
    this->sbutton->setFlat(true);
    this->sbutton->setIconSize(QSize(142,53));
    this->sbutton->setGeometry(300,80,150,50);
    this->sbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");
    this->connect(this->sbutton,SIGNAL(clicked()),this,SLOT(selecttosign()));

    //ѡ����Ϸ�Ѷ�
    this->gbutton = new QPushButton(this);
    this->gbutton->setIcon(QIcon("image/btn/gamerank.png"));
    this->gbutton->setFlat(true);
    this->gbutton->setIconSize(QSize(142,53));
    this->gbutton->setGeometry(300,150,150,50);
    this->gbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");
    this->connect(this->gbutton,SIGNAL(clicked()),this,SLOT(gametosign()));

    //ѡ�����ֿ���
    this->mbutton = new QPushButton(this);
    this->mbutton->setIcon(QIcon("image/btn/music_on.png"));
    this->mbutton->setFlat(true);
    this->mbutton->setIconSize(QSize(142,53));
    this->mbutton->setGeometry(300,220,150,50);
    this->mbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");
    this->connect(this->mbutton,SIGNAL(clicked()),this,SLOT(musictosign()));

    //������������
    this->nbutton = new QPushButton(this);
    this->nbutton->setIcon(QIcon("image/btn/newplayero.png"));
    this->nbutton->setFlat(true);
    this->nbutton->setIconSize(QSize(142,53));
    this->nbutton->setGeometry(300,290,150,50);
    this->nbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");
    this->connect(this->nbutton,SIGNAL(clicked()),this,SLOT(newtosign()));

    //���ذ�ť
    this->rbutton = new QPushButton(this);
    this->rbutton->setIcon(QIcon("image/btn/back.png"));
    this->rbutton->setFlat(true);
    this->rbutton->setIconSize(QSize(142,53));
    this->rbutton->setGeometry(300,360,150,50);
    this->rbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");
    this->connect(this->rbutton,SIGNAL(clicked()),this,SLOT(returntosign()));
    this->rbutton->setShortcut(Qt::Key_Escape);
}

void SetupWidget::musictosign()
{
    if(true==MenuWidget::music->isFinished())
    {
        MenuWidget::music->play();
        this->mbutton->setIcon(QIcon("image/btn/music_on.png"));
    }
    else
    {
        MenuWidget::music->stop();
        this->mbutton->setIcon(QIcon("image/btn/music_off1.png"));
    }
}

void SetupWidget::returntosign()
{
    this->hide();
    CUIPoint::mw->show();
}

void SetupWidget::selecttosign()
{
    this->hide();
    CUIPoint::sw->show();
}

void SetupWidget::newtosign()
{
    //////////////////�����������ݿ���ȡģ��////////////////
    mydata = Sqldata::getIstance();
    QSqlDatabase db = Sqldata::getdb();
    QSqlQuery query(db);
    QString S =QString("select * from people where name='%1'and psw='%2'").arg(Widget::usernames).arg(Widget::passwords);
    query.exec(S);
    /////////////////////
    newflag = !newflag;
    if(newflag == true)
    {
        this->nbutton->setIcon(QIcon("image/btn/newplayero.png"));
        QString newagain = QString("0");
        if(query.next())
        {
            QString S2 = QString("update people set isagain='%1'  where name='%2'and psw='%3'").arg(newagain).arg(Widget::usernames).arg(Widget::passwords);
            query.exec(S2);
            qDebug()<<S2;
            qDebug()<<query.value(4).toInt();
        }
        /////////////////////////////////////
    }
    else
    {
        this->nbutton->setIcon(QIcon("image/btn/newplayerc.png"));
        QString newagains = QString("1");
        if(query.next())
        {
            QString S3 = QString("update people set isagain='%1'  where name='%2'and psw='%3'").arg(newagains).arg(Widget::usernames).arg(Widget::passwords);
            query.exec(S3);
            qDebug()<<S3;
            qDebug()<<query.value(4).toInt();
        }
        /////////////////////////////////////
    }
}

void SetupWidget::gametosign()
{
    this->hide();
    CUIPoint::gw->show();
}
