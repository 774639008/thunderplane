#ifndef FINDWIDGET_H
#define FINDWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QIcon>
#include <QLineEdit>
#include <QComboBox>
#include <QPushButton>
#include "sqldata.h"

class FindWidget : public QWidget
{
    Q_OBJECT
public:
    explicit FindWidget(QWidget *parent = 0);

signals:

public slots:
    void FSignalTooButton();
    void FSignalToqButton();

private:
    QLabel *label;
    QLabel *UserName;
    QLabel *ProTected;
    QLineEdit *UserNameText;
    QLineEdit *ProTectedText;
    QLineEdit *PasswordText;
    QComboBox *comboBox;
    QPushButton *obutton;
    QPushButton *qbutton;
    Sqldata *mydata;
};

#endif // FINDWIDGET_H
