#ifndef QENEMY_H
#define QENEMY_H
#include "pixmapitem.h"
#include "qenemy.h"
#include "qbolling.h"


class QEnemy :public PixmapItem
{
public:
    QEnemy(const QString &filename,QGraphicsScene *scene,int path);
    void advance(int phase);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    void enemydeath(int harm);
    void docolling();
private:
    int path;
    QEnemy *enemy;
    QRectF rect;
    int hp;

};

#endif // QENEMY_H
