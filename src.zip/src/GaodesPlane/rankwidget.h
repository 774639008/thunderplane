#ifndef RANKWIDGET_H
#define RANKWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QIcon>
#include <QPushButton>
#include <QTableWidget>
#include <QTableView>
#include "sqldata.h"

class RankWidget : public QWidget
{
    Q_OBJECT
public:
    explicit RankWidget(QWidget *parent = 0);

signals:

public slots:
    void NexttoSignal();
    void PretoSignal();
    void RtoSignal();

private:
    QLabel *label;
    QPushButton *nextbutton;
    QPushButton *prebutton;
    QPushButton *rbutton;
    QTableWidget *hisTableWidget;
    QTableView *view;
    Sqldata *mydata;
};

#endif // RANKWIDGET_H
