#include "gameview.h"
#include "menuwidget.h"
#include "qbullet.h"
#include "sqldata.h"
#include "selectwidget.h"
#include "rollingwidget.h"
#include "mydialog.h"
#include "myrankwidget.h"
#include "widget.h"
#include <stdio.h>
#include <Qtsql/QSqlDatabase>
#include <Qtsql/QSqlQuery>
#include <QMutex>
#include <QWaitCondition>
#include <QDebug>


GameView::GameView(QWidget *parent):QGraphicsView(parent)
{
    this->setMouseTracking(true);
    this->parent = parent;
    QPlane::gameover = 0;
    mydialog::dflag = 0;
    this->timernum = 0;
    this->retimernum = 0;
    this->resize(600,650);
    this->setStyleSheet("background:transparent;border:0px");
    this->setWindowIcon(QIcon("image/icon.png"));
    this->setWindowTitle("����ս��");

    this->scene = new QGraphicsScene;
    this->scene->setSceneRect(0,0,600,650);
    this->setScene(scene);

    key_space = false;
    key_esc = false;

    this->plane = new QPlane(SelectWidget::PlaneName,scene,this->parent);
    this->plane->setPos(this->width()/2,this->height());

    timer = new QTimer;
    this->connect(timer,SIGNAL(timeout()),this->scene,SLOT(advance()));

    timer2 = new QTimer;
    this->connect(timer2,SIGNAL(timeout()),this,SLOT(productplane()));


    timer3 = new QTimer;
    this->connect(timer3,SIGNAL(timeout()),this,SLOT(productbullet()));
    if(RollingWidget::retime == 0)
    {
        timer4 = new QTimer;
        this->connect(timer4,SIGNAL(timeout()),this,SLOT(timers()));
        timer4->start(1000);
    }
    else
    {
        this->timer2->start(1000);
        this->timer->start(100);
        this->timer3->start(70);
        retimernum =4;
        timernum=4;
    }

    timer5 = new QTimer;
    this->connect(timer5,SIGNAL(timeout()),this,SLOT(timerfive()));
    timer5->start(1000);

}

void GameView::mouseMoveEvent(QMouseEvent *event)
{
    if(retimernum>3)
    {
        QPoint p;
        p=event->pos();
        this->plane->setPos(p.x(),p.y());
    }
}

void GameView::productplane()
{
        if(timernum<3)
        {
            this->timer2->stop();
            this->timer->stop();
            this->timer3->stop();
        }
        else
        {
            this->timer2->start(1000);
            this->timer->start(100);
            this->timer3->start(70);
        }

        mydata = Sqldata::getIstance();
        QSqlDatabase db = Sqldata::getdb();
        QSqlQuery query(db);
        QString dbname;
        char buf[200]="";
        if(GameRankWidget::Rankid == 1)
        {
            sprintf(buf,"select * from productplane1 where time = %d",this->timernum++);
        }
        else if (GameRankWidget::Rankid == 2)
        {
            sprintf(buf,"select * from productplane2 where time = %d",this->timernum++);
        }
        else if(GameRankWidget::Rankid == 3)
        {
            sprintf(buf,"select * from productplane3 where time = %d",this->timernum++);
        }
        else   //�ο�
        {
            sprintf(buf,"select * from productplane where time = %d",this->timernum++);
        }
        query.exec(buf);
        query.next();
        QString enemy = query.value(2).toString();
        int type = query.value(3).toInt();
        for(int i = 0;i<query.value(1).toInt();i++)
        {
            this->enemy1 = new QEnemy(enemy,scene,type);
            this->enemy1->setPos(500,0);
        }

        if(timernum == 4&&GameRankWidget::Rankid == 1)
        {
            this->enemy2 = new QEnemy("image/enemy/01.png",scene,1);
                     this->enemy2->setPos(0,100);
                     this->enemy2->moveBy(10,0);
             this->enemy2 = new QEnemy("image/enemy/01.png",scene,1);
                     this->enemy2->setPos(0,150);
                     this->enemy2->moveBy(10,0);
        }
        else if(timernum == 10&&GameRankWidget::Rankid == 2)
        {
            this->enemy2 = new QEnemy("image/enemy/04.png",scene,1);
                     this->enemy2->setPos(0,100);
                     this->enemy2->moveBy(10,0);
             this->enemy2 = new QEnemy("image/enemy/04.png",scene,1);
                     this->enemy2->setPos(0,150);
                     this->enemy2->moveBy(10,0);

            this->enemy2 = new QEnemy("image/enemy/04.png",scene,1);
                    this->enemy2->setPos(0,200);
                    this->enemy2->moveBy(10,0);
        }
        else if(timernum == 10&&GameRankWidget::Rankid == 3)
        {
            this->enemy2 = new QEnemy("image/enemy/05.png",scene,2);
                     this->enemy2->setPos(0,100);
                     this->enemy2->moveBy(10,0);
             this->enemy2 = new QEnemy("image/enemy/05.png",scene,2);
                     this->enemy2->setPos(0,150);
                     this->enemy2->moveBy(10,0);

            this->enemy2 = new QEnemy("image/enemy/05.png",scene,2);
                    this->enemy2->setPos(0,200);
                    this->enemy2->moveBy(10,0);

            this->enemy2 = new QEnemy("image/enemy/05.png",scene,2);
                    this->enemy2->setPos(0,250);
                    this->enemy2->moveBy(10,0);

            this->enemy2 = new QEnemy("image/enemy/05.png",scene,2);
                    this->enemy2->setPos(0,300);
                    this->enemy2->moveBy(10,0);
        }
        else if(timernum == 20)
        {

        }

}

void GameView::keyPressEvent(QKeyEvent *event)
{
    if(!event->isAutoRepeat())
    {
        if(!key_space && event->key() == Qt::Key_Space)
        {
             key_space = true;
        }
        if(!key_esc && event->key() == Qt::Key_Escape)
        {
            key_esc = true;
        }
    }
}

void GameView::keyReleaseEvent(QKeyEvent *event)
{
    if(!event->isAutoRepeat())
    {
        if(key_space && event->key() == Qt::Key_Space)
        {
             key_space = false;
        }
        if(key_esc && event->key() == Qt::Key_Escape)
        {
            key_esc = false;
            key_space = false;
        }
    }
}

void GameView::productbullet()
{
    if(key_space == true)
    {
        this->bullet = new QBullet(SelectWidget::BulletName,this->scene,type_m_bullet);
        this->bullet->setPos(this->plane->x(),this->plane->y()-100);
    }
    if(key_esc == true)
    {
        this->timer2->stop();
        this->timer->stop();
        this->timer3->stop();
        key_space = false;
        if(RollingWidget::retime == 0)   //��Ҫ�����ж� ����û�п�����ʱ��4 stop�����
        {
            this->timer4->stop();
        }
        key_esc = false;
        this->setAttribute(Qt::WA_TransparentForMouseEvents,true);
        mydialog *md = new mydialog("image/vcard-bg.png");
        md->show();
    }
    if(QPlane::gameover == 1)
    {
        this->timer2->stop();
        this->timer->stop();
        this->timer3->stop();
        MyrankWidget * rkw = new MyrankWidget;
        rkw->show();
        delete this->parent;
    }

}

void GameView::timers()
{
    if(retimernum == 0)
    {
        this->bl=  new QBolling("image/3.png",scene);
        this->bl->setPos(300,300);
    }
    else if(retimernum == 1)
    {
        this->bl->hide();
        this->b2=  new QBolling("image/2.png",scene);
        this->b2->setPos(300,300);
    }
    else if(retimernum == 2)
    {
        this->b2->hide();
        this->b3=  new QBolling("image/1.png",scene);
        this->b3->setPos(300,300);
    }
    else
    {
       this->b3->hide();
       this->timer2->start(1000);
       this->timer->start(100);
       timer3->start(70);
    }
    retimernum++;
}

void GameView::timerfive()
{
    if(mydialog::dflag == 1)
    {
        this->timer2->start(1000);
        this->timer->start(100);
        this->timer3->start(70);
        this->setAttribute(Qt::WA_TransparentForMouseEvents,false);
    }
    if(mydialog::dflag == 2)
    {
        delete this->parent;
        CUIPoint::mw->show();
    }
}


