/****************************************************************************
** Meta object code from reading C++ file 'selectwidget.h'
**
** Created: Thu Oct 11 16:22:09 2018
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../Thunder Plane/GaodesPlane/selectwidget.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'selectwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_SelectWidget[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x0a,
      26,   13,   13,   13, 0x0a,
      38,   13,   13,   13, 0x0a,
      52,   13,   13,   13, 0x0a,
      63,   13,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_SelectWidget[] = {
    "SelectWidget\0\0buttonone()\0buttontwo()\0"
    "buttonthree()\0OkButton()\0QuitButton()\0"
};

const QMetaObject SelectWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_SelectWidget,
      qt_meta_data_SelectWidget, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &SelectWidget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *SelectWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *SelectWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SelectWidget))
        return static_cast<void*>(const_cast< SelectWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int SelectWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: buttonone(); break;
        case 1: buttontwo(); break;
        case 2: buttonthree(); break;
        case 3: OkButton(); break;
        case 4: QuitButton(); break;
        default: ;
        }
        _id -= 5;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
