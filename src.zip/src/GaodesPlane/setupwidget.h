#ifndef SETUPWIDGET_H
#define SETUPWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QIcon>
#include <QPushButton>
#include "sqldata.h"

class SetupWidget : public QWidget
{
    Q_OBJECT
public:
    explicit SetupWidget(QWidget *parent = 0);

signals:

public slots:
    void selecttosign();
    void musictosign();
    void returntosign();
    void newtosign();
    void gametosign();

private:
    QLabel *label;
    QPushButton *sbutton;
    QPushButton *gbutton;
    QPushButton *mbutton;
    QPushButton *rbutton;
    QPushButton *nbutton;
    bool newflag;
    Sqldata *mydata;
};

#endif // SETUPWIDGET_H
