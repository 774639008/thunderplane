#include "qenemy.h"
#include <stdio.h>
#include "qbullet.h"

QEnemy::QEnemy(const QString &filename,QGraphicsScene *scene,int path):PixmapItem(filename,scene)
{
     this->setPos(50,100+qrand()%600);
     this->path = path;
     this->item_type = type_enemy;
     this->scene = scene;
     this->hp = 10;
 //    this->flag = flag;
}

void QEnemy::advance(int phase)
{
    if(mapToScene(0,0).y()<=0|mapToScene(0,0).x()>=800)
    {
        setPos(-100,qrand()%300);
    }
    if(path == 0)
    {
        int speed = qrand()%10;
        this->setPos(mapToScene(speed,2));
    }
    else
    {
        this->setPos(mapToScene(10,0));
    }

    //�л��ӵ�
    static int i = 0;
    i = ++i%100;
    if(1 == i)
    {
        if(this->path == 1)
        {
            QBullet *bullets = new QBullet("image/bullet/bullet-106.png",this->scene,type_e_bullet);
            bullets->setPos(this->x(),this->y());
        }
        else if(this->path == 2)
        {
            QBullet *bullets1 = new QBullet("image/bullet/bullet-102.png",this->scene,type_e_bullet);
            bullets1->setPos(this->x(),this->y());
        }
        else if(this->path == 3)
        {
            QBullet *bullets2 = new QBullet("image/bullet/bullet-101.png",this->scene,type_e_bullet);
            bullets2->setPos(this->x(),this->y());
        }
    }
}

void QEnemy::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{

    painter->drawPixmap(-pixmap.width()/2,-pixmap.height(),pixmap.width(),pixmap.height(),pixmap);

    if(this->collidingItems().count()>0)
    {
        docolling();
    }
}

void QEnemy::enemydeath(int harm)
{
    this->hp -= harm;
    if(this->hp <=0 )
    {
        this->setPos(1000,1000);
    }
}

void QEnemy::docolling()
{
    if(this->collidingItems().count() > 0)
    {
        QList<QGraphicsItem*> list = this->collidingItems();
        QList<QGraphicsItem*>::iterator i;

        QBullet *vector;//����һ������
        i = list.begin();
        while(i != list.end())
        {
            vector = (QBullet *)(*i);
            if(vector->item_type== type_m_bullet)//�л��ӵ����ҷ��ɻ�
            {

                //��ըЧ��Bomb
                QBomb *bomb = new QBomb("image/bomb/1.png",this->scene);
                bomb->setPos(mapToScene(0,0).x(),mapToScene(0,0).y()-100);

                this->enemydeath(10);
                vector->delebullet();
            }
            else if(vector->item_type==type_myplane) //�ҷ��ӵ���л�
            {
                QBomb *bomb = new QBomb("image/bomb/1.png",this->scene);
                bomb->setPos(mapToScene(0,0).x(),mapToScene(0,0).y()-100);

                this->enemydeath(30);
                QPlane *plane;
                plane = (QPlane *)(vector);
                plane->been_hit(30);
            }
            i++;
        }
    }
}
