#ifndef QPLANE_H
#define QPLANE_H
#include "pixmapitem.h"
#include "qbullet.h"
#include "qenemy.h"
#include <QMouseEvent>
#include <QLabel>
#include <QProgressBar>
#include "sqldata.h"

class QPlane : public PixmapItem
{
public:
    QPlane(const QString &filename,QGraphicsScene *scene,QWidget *parent = 0);
    void advance(int phase);
    int blood;
    static int bloodid;
    void doingcollding();
    void been_hit(int harm);    //������(int �˺�)
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    static int gameover;
private:
    int flag;
    QRectF rect;
    Sqldata *mydata;
    QLabel *label;
    QWidget *parent;
    QProgressBar *pProgressBar;
};

#endif // QPLANE_H
