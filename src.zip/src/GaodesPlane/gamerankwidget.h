#ifndef GAMERANKWIDGET_H
#define GAMERANKWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QIcon>
#include <QPushButton>
#include <QLabel>
#include <QMessageBox>
#include "sqldata.h"
#include "cuipoint.h"

class GameRankWidget : public QWidget
{
    Q_OBJECT
public:
    explicit GameRankWidget(QWidget *parent = 0);
    static QString SceneName;
    static int Rankid;

signals:

public slots:
    void OkbuttonClick();
    void QbuttonClcik();
    void NextbuttonClick();
    void PrebuttonClick();

private:
    QLabel *label1;
    QPushButton *nextbutton;
    QPushButton *prebutton;
    QPushButton *okbutton;
    QPushButton *qbutton;
    QLabel *label2;
    QLabel *label3;
    Sqldata *mydata;
    Sqldata *mydata2;
    int flag;
    int flag2;
    QString temp;
    QString temp2;
};

#endif // GAMERANKWIDGET_H
