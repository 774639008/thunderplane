#include "qbomb.h"
#include <stdio.h>

QBomb::QBomb(const QString & filename,QGraphicsScene *scene):PixmapItem(filename,scene)
{
        this->item_type = type_bomb;
}
void QBomb::advance(int phase)
{
       if(this->collidingItems().count() > 0)
       {
        this->hide();
       }
       delete this;//ɾ����ըЧ��
}

void QBomb::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    char filename[50]="0";
    static int i = 2;
    if(i == 8)
        i=1;
    sprintf(filename,"image/bomb/%d.png",i++);
    pixmap.load(filename);
    painter->drawPixmap(-pixmap.width()/2,-pixmap.height(),pixmap.width(),pixmap.height(),pixmap);
}
