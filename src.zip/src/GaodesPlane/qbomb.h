#ifndef QBOMB_H
#define QBOMB_H

#include "PixmapItem.h"

class QBomb:public PixmapItem
{
public:
    QBomb(const QString & filename,QGraphicsScene *scene);
    void advance(int phase);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};

#endif // QBOMB_H
