#ifndef SELECTWIDGET_H
#define SELECTWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QIcon>
#include <QPushButton>

class SelectWidget : public QWidget
{
    Q_OBJECT
public:
    explicit SelectWidget(QWidget *parent = 0);
    static QString PlaneName;
    static QString BulletName;
signals:

public slots:
    void buttonone();
    void buttontwo();
    void buttonthree();
    void OkButton();
    void QuitButton();
private:
    QLabel *label1;
    QPushButton *button1;
    QPushButton *button2;
    QPushButton *button3;
    QPushButton *obutton;
    QPushButton *qbutton;
    int flag;

};

#endif // SELECTWIDGET_H
