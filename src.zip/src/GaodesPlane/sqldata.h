#ifndef SQLDATA_H
#define SQLDATA_H

#include <QWidget>
#include <QSqlDatabase>
#include <QMutex>
#include <QSqlQuery>

static QString sqldataplace;

class Sqldata : public QWidget
{
    Q_OBJECT
public:
    static Sqldata*getIstance(); //����
    static QSqlDatabase getdb();
signals:

private:
    static Sqldata *instance;
    explicit Sqldata(QWidget *parent = 0);
    static QSqlDatabase db;
};

#endif // SQLDATA_H
