#ifndef MYDIALOG_H
#define MYDIALOG_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>

class mydialog : public QWidget
{
    Q_OBJECT
public:
    explicit mydialog(const QString &filename,QWidget *parent = 0);
    static int dflag;

signals:

public slots:
    void OkLink();
    void QLink();

private:
    QLabel *label;
    QPushButton *okbutton;
    QPushButton *qbutton;

};

#endif // MYDIALOG_H
