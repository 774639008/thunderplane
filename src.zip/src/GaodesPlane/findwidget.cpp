#include "findwidget.h"
#include "cuipoint.h"
#include <QRegExpValidator>
#include <QMessageBox>

extern QSqlQuery query;

FindWidget::FindWidget(QWidget *parent) :
    QWidget(parent)
{
    setWindowFlags(Qt::FramelessWindowHint);

    this->setFixedSize(600,400);
    this->label = new QLabel(this);
    this->label->setGeometry(0,0,600,400);
    this->label->setPixmap(QPixmap("image/bg3_startcg.png"));

    this->setWindowIcon(QIcon("image/icon.png"));
    this->setWindowTitle("����ս��");


    //���ñ�ǩ��
    this->UserName = new QLabel(this);
    this->UserName->setGeometry(150,80,50,50);
    this->UserName->setPixmap(QPixmap("image/key.png"));

    this->ProTected = new QLabel(this);
    this->ProTected->setGeometry(150,140,50,50);
    this->ProTected->setPixmap(QPixmap("image/key.png"));

    this->ProTected = new QLabel(this);
    this->ProTected->setGeometry(150,200,50,50);
    this->ProTected->setPixmap(QPixmap("image/key.png"));

    //�༭��
    QRegExp rep("[a-zA-Z\\w]{1,14}");
    QRegExpValidator *v =new QRegExpValidator(rep,this);
    this->UserNameText = new QLineEdit(this);
    this->UserNameText->setGeometry(200,87,180,25);
    this->UserNameText->setValidator(v);
    this->UserNameText->setPlaceholderText("�һص��û���");

    this->ProTectedText = new QLineEdit(this);
    this->ProTectedText->setGeometry(200,170,180,25);
    this->ProTectedText->setValidator(v);
    this->ProTectedText->setPlaceholderText("�ܱ���");

    QRegExp rep1("[0-9]{1,8}");
    QRegExpValidator *v2 =new QRegExpValidator(rep1,this);
    this->PasswordText = new QLineEdit(this);
    this->PasswordText->setGeometry(200,230,180,25);
    this->PasswordText->setValidator(v2);
    this->PasswordText->setPlaceholderText("�µ�����");
    this->PasswordText->setEchoMode(QLineEdit::Password);

    //ʵ�� QComboBox
    this->comboBox = new QComboBox(this);
    //�ؼ���ʾλ�ô�С
    comboBox->setGeometry(QRect(200,137,180,25));

    //�����ַ����б�
    QStringList str;
    str << "���������Ǽ��¼���" << "���ĸ������ֽ�ʲô" << "����ĸ�����ֽ�ʲô";
    //���ַ����б��� QComboBox �ؼ�
    comboBox->addItems(str);
    comboBox->show();

    //���ư�ť
    this->obutton = new QPushButton(this);
    this->obutton->setIcon(QIcon("image/btn/ok.png"));
    this->obutton->setFlat(true);
    this->obutton->setIconSize(QSize(142,53));
    this->obutton->setGeometry(150,300,142,53);
    this->obutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/ok1.png);}");

    connect(this->obutton,SIGNAL(clicked()),this,SLOT(FSignalTooButton()));
    this->obutton->setShortcut(Qt::Key_Return);

    this->qbutton = new QPushButton(this);
    this->qbutton->setIcon(QIcon("image/btn/Cancel.png"));
    this->qbutton->setFlat(true);
    this->qbutton->setIconSize(QSize(142,53));
    this->qbutton->setGeometry(330,300,142,53);
    this->qbutton->setStyleSheet("QPushButton:hover{border-image:url(image/btn/Cancel1.png);}");

    connect(this->qbutton,SIGNAL(clicked()),this,SLOT(FSignalToqButton()));
    this->qbutton->setShortcut(Qt::Key_Escape);
}

void FindWidget::FSignalTooButton()
{
//    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
//    db.setDatabaseName("db/data.db");
//    db.open();
//    QSqlQuery query(db);

    mydata = Sqldata::getIstance();
    QSqlDatabase db = Sqldata::getdb();
    QSqlQuery query(db);

    QString UName = UserNameText->text();
    QString Pword;
    QString Qid;
    if(UserNameText->text().count()!=0||ProTectedText->text().count()!=0)
    {
        if(comboBox->currentText().compare("���������Ǽ��¼���")==0)
        {
            Qid = QString("1");
        }else if(comboBox->currentText().compare("���ĸ������ֽ�ʲô")==0)
        {
            Qid = QString("2");
        }else if(comboBox->currentText().compare("����ĸ�����ֽ�ʲô")==0)
        {
            Qid = QString("3");
        }
        QString S =QString("select * from people where name='%1'and qid='%2'").arg(UName).arg(Qid);
        query.exec(S);
        QString Question;
        QString newpsw;
        if(query.next())
        {
          Question = QString(query.value(2).toString());
        }
        QString S1 =QString("select * from people where name='%1'and qid='%2' and question='%3' ").arg(UName).arg(Qid).arg(Question);
        query.exec(S1);
        if(query.next())
        {
            Pword=QString("%1").arg(query.value(1).toInt());
            newpsw = PasswordText->text();
            QString S2 = QString("update people set psw='%1'  where name='%2'and qid='%3' and question='%4' ").arg(newpsw).arg(UName).arg(Qid).arg(Question);
            query.exec(S2);
            QMessageBox::warning(NULL,"�޸�����ɹ�","��֮ǰ�ľ�������"+Pword);
        }
        else
            QMessageBox::warning(NULL,"Error","�ܱ����������ԣ�����");
        this->UserNameText->clear();
        this->ProTectedText->clear();
        this->PasswordText->clear();
        this->close();
        CUIPoint::fw->show();
    }
    else if(UserNameText->text().count() == 0||ProTectedText->text().count()==0)
        QMessageBox::warning(NULL,"Error","����д������Ϣ������");
    else
        QMessageBox::warning(NULL,"Error","�鲻���������ԣ�����");
    this->UserNameText->clear();
    this->ProTectedText->clear();
    this->PasswordText->clear();
}

void FindWidget::FSignalToqButton()
{
    this->close();
    CUIPoint::w->show();
}
